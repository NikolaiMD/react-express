const express = require('express')
const app = express()
const port = 3000
const fs = require('fs')

//routing
// app.get('/', (req, res) => res.send('Hello World!'))
//RESTFUL routing / RESOURCE routing
// ############################################## CONTROLLER ####################################################
const productDetails=(req, res) =>{
    console.log(req.params.productid);
    fs.readFile('./database/products.json', (err, data)=>{
        // callbacks contain ERRORS or DATA
        if(!err){
            let products = JSON.parse(data);

            let product =  products.find(p => p.id == req.params.productid)
            // console.log()
            // console.log(data.toString())


            // res.append('Content-type', 'application/json')
            // res.send(product)
            res.jsonp(product)
        }
        // console.log(err)
    })
}
const productDelete=(req, res) =>{
    console.log(req.params.productid);
    fs.readFile('./database/products.json', (err, data)=>{
        // callbacks contain ERRORS or DATA
        if(!err){
            let products = JSON.parse(data);

            let product =  products.find(p => p.id == req.params.productid)
            // console.log()
            // console.log(data.toString())


            // res.append('Content-type', 'application/json')
            // res.send(product)
            res.jsonp(product)
        }
        // console.log(err)
    })
}
const productIndex=(req, res) =>{
    fs.readFile('./database/products.json', (err, data)=>{
        // callbacks contain ERRORS or DATA
        if(!err){
            
            // console.log(data.toString())
            res.append('Content-type', 'application/json')
            res.send(data.toString())
        }
        // console.log(err)
    })
}
// ############################################## ROUTING ####################################################
app.get('/products', productIndex)
app.get('/products/:productid', productDetails)
app.delete('/products/:productid', productDelete)


app.listen(port, () => console.log(`Server started on ${port}!`))